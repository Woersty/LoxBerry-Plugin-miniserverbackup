# LoxBerry-Plugin-miniserverbackup
A LoxBerry Plugin
-
For Details visit http://www.loxwiki.eu/display/LOXBERRY/Plugins#Plugins-Miniserver-Backup
